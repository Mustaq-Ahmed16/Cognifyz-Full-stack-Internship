const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const port = 3000;

//Middle ware to parse the body of POST request

app.use(bodyParser.urlencoded({ extended: true }));

//set EJS as templating engine

app.set("view engine", "ejs");

//Route to serve the form
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

//Route to handle form submission

app.post("/submit", (req, res) => {
  let { name, email, clgname, option } = req.body;
  res.render("response.ejs", { name, email, clgname, option });
});

app.listen(port, () => {
  console.log(`Server running at port : ${port}`);
});