const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const app = express();
const port = 3000;

// Middleware to parse the body of POST requests
app.use(bodyParser.urlencoded({ extended: true }));

// Set up session middleware
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: true,
}));

// Set EJS as the templating engine
app.set('view engine', 'ejs');

// Route to serve the form
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Route to handle form submission
app.post('/submit', (req, res) => {
  const { name, email, message } = req.body;
  const errors = {};

  // Server-side validation
  if (name.length < 3) {
    errors.name = 'Name must be at least 3 characters long.';
  }
  const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  if (!emailPattern.test(email)) {
    errors.email = 'Invalid email format.';
  }
  if (message.length < 10) {
    errors.message = 'Message must be at least 10 characters long.';
  }

  if (Object.keys(errors).length > 0) {
    res.render('response', { errors, name, email, message });
  } else {
    // Store validated data in session
    req.session.userData = { name, email, message };
    res.render('response', { name, email, message, errors: null });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
